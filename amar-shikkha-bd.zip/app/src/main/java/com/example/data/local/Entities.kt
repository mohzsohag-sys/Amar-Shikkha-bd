package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val chapterId: String,
  val chapterTitle: String,
  val subjectName: String,
  val classGradeName: String,
  val totalQuestions: Int,
  val correctAnswers: Int,
  val wrongAnswers: Int,
  val percentage: Int,
  val gradeLetter: String,
  val gradeTitle: String,
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_profile")
data class StudentProfileEntity(
  @PrimaryKey
  val id: Int = 1,
  val studentName: String = "অয়ন আহমেদ",
  val className: String = "৩য় শ্রেণি",
  val rollNumber: String = "০৫",
  val schoolName: String = "আদর্শ সরকারি প্রাথমিক বিদ্যালয়",
  val avatarId: Int = 0,
  val totalPoints: Int = 120,
  val starsCount: Int = 15
)

package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CurriculumData
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.ShikkhaDatabase
import com.example.data.local.StudentProfileEntity
import com.example.data.repository.ShikkhaRepository
import com.example.model.BengaliUtils
import com.example.model.Chapter
import com.example.model.ClassGrade
import com.example.model.QuizSummary
import com.example.model.SubjectType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class Screen {
  object Home : Screen()
  object SubjectChapters : Screen()
  object LessonDetail : Screen()
  object QuizSession : Screen()
  object QuizResult : Screen()
  object ExamHistory : Screen()
  object Profile : Screen()
}

data class QuizUiState(
  val chapter: Chapter? = null,
  val currentQuestionIndex: Int = 0,
  val selectedOptionIndex: Int? = null,
  val isAnswerConfirmed: Boolean = false,
  val userAnswers: Map<Int, Int> = emptyMap(), // question index to option index
  val correctAnswersCount: Int = 0,
  val wrongAnswersCount: Int = 0,
  val isFinished: Boolean = false,
  val resultSummary: QuizSummary? = null
)

class ShikkhaViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: ShikkhaRepository

  init {
    val database = ShikkhaDatabase.getDatabase(application, viewModelScope)
    repository = ShikkhaRepository(database.shikkhaDao())
  }

  // Navigation Stack
  private val _screenStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
  private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
  val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

  // Selected Grade and Subject
  private val _selectedGrade = MutableStateFlow(ClassGrade.CLASS_1)
  val selectedGrade: StateFlow<ClassGrade> = _selectedGrade.asStateFlow()

  private val _selectedSubject = MutableStateFlow(SubjectType.BANGLA)
  val selectedSubject: StateFlow<SubjectType> = _selectedSubject.asStateFlow()

  private val _selectedChapter = MutableStateFlow<Chapter?>(null)
  val selectedChapter: StateFlow<Chapter?> = _selectedChapter.asStateFlow()

  // Search query for lessons
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Quiz State
  private val _quizState = MutableStateFlow(QuizUiState())
  val quizState: StateFlow<QuizUiState> = _quizState.asStateFlow()

  // Room Data
  val allQuizAttempts: StateFlow<List<QuizAttemptEntity>> = repository.allAttempts
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

  val studentProfile: StateFlow<StudentProfileEntity?> = repository.studentProfile
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = StudentProfileEntity()
    )

  fun navigateTo(screen: Screen) {
    _screenStack.update { current ->
      if (current.lastOrNull() == screen) current else current + screen
    }
    _currentScreen.value = screen
  }

  fun navigateBack(): Boolean {
    if (_screenStack.value.size > 1) {
      _screenStack.update { it.dropLast(1) }
      _currentScreen.value = _screenStack.value.lastOrNull() ?: Screen.Home
      return true
    }
    return false
  }

  fun selectGrade(grade: ClassGrade) {
    _selectedGrade.value = grade
  }

  fun selectSubject(subject: SubjectType) {
    _selectedSubject.value = subject
    navigateTo(Screen.SubjectChapters)
  }

  fun openChapter(chapter: Chapter) {
    _selectedChapter.value = chapter
    navigateTo(Screen.LessonDetail)
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  // Start Quiz
  fun startQuiz(chapter: Chapter) {
    _selectedChapter.value = chapter
    _quizState.value = QuizUiState(
      chapter = chapter,
      currentQuestionIndex = 0,
      selectedOptionIndex = null,
      isAnswerConfirmed = false,
      userAnswers = emptyMap(),
      correctAnswersCount = 0,
      wrongAnswersCount = 0,
      isFinished = false,
      resultSummary = null
    )
    navigateTo(Screen.QuizSession)
  }

  fun selectQuizOption(optionIndex: Int) {
    if (_quizState.value.isAnswerConfirmed) return
    _quizState.update { it.copy(selectedOptionIndex = optionIndex) }
  }

  fun confirmAnswer() {
    val state = _quizState.value
    val chapter = state.chapter ?: return
    val selectedIndex = state.selectedOptionIndex ?: return
    if (state.isAnswerConfirmed) return

    val currentQuestion = chapter.questions[state.currentQuestionIndex]
    val isCorrect = selectedIndex == currentQuestion.correctIndex

    val updatedAnswers = state.userAnswers.toMutableMap()
    updatedAnswers[state.currentQuestionIndex] = selectedIndex

    _quizState.update {
      it.copy(
        isAnswerConfirmed = true,
        userAnswers = updatedAnswers,
        correctAnswersCount = if (isCorrect) it.correctAnswersCount + 1 else it.correctAnswersCount,
        wrongAnswersCount = if (!isCorrect) it.wrongAnswersCount + 1 else it.wrongAnswersCount
      )
    }
  }

  fun nextQuestion() {
    val state = _quizState.value
    val chapter = state.chapter ?: return
    val nextIndex = state.currentQuestionIndex + 1

    if (nextIndex < chapter.questions.size) {
      _quizState.update {
        it.copy(
          currentQuestionIndex = nextIndex,
          selectedOptionIndex = null,
          isAnswerConfirmed = false
        )
      }
    } else {
      // Quiz Finished! Calculate marks and percentage
      finishQuiz()
    }
  }

  private fun finishQuiz() {
    val state = _quizState.value
    val chapter = state.chapter ?: return
    val total = chapter.questions.size
    val correct = state.correctAnswersCount
    val wrong = state.wrongAnswersCount
    val percentage = if (total > 0) (correct * 100) / total else 0
    val (gradeLetter, gradeTitle) = BengaliUtils.getGradeDetails(percentage)

    val summary = QuizSummary(
      chapterId = chapter.id,
      chapterTitle = chapter.title,
      subjectType = chapter.subjectType,
      classGrade = chapter.classGrade,
      totalQuestions = total,
      correctCount = correct,
      wrongCount = wrong,
      percentage = percentage,
      gradeLetter = gradeLetter,
      gradeTitle = gradeTitle,
      userSelectedAnswers = state.userAnswers
    )

    _quizState.update {
      it.copy(
        isFinished = true,
        resultSummary = summary
      )
    }

    // Save to Room DB asynchronously
    viewModelScope.launch {
      val entity = QuizAttemptEntity(
        chapterId = chapter.id,
        chapterTitle = chapter.title,
        subjectName = chapter.subjectType.banglaName,
        classGradeName = chapter.classGrade.banglaName,
        totalQuestions = total,
        correctAnswers = correct,
        wrongAnswers = wrong,
        percentage = percentage,
        gradeLetter = gradeLetter,
        gradeTitle = gradeTitle
      )
      repository.saveQuizResult(entity)
    }

    navigateTo(Screen.QuizResult)
  }

  fun updateProfile(
    name: String,
    className: String,
    roll: String,
    school: String,
    avatarId: Int
  ) {
    viewModelScope.launch {
      val current = studentProfile.value ?: StudentProfileEntity()
      val updated = current.copy(
        studentName = name.ifBlank { "অয়ন আহমেদ" },
        className = className.ifBlank { "৩য় শ্রেণি" },
        rollNumber = roll.ifBlank { "০১" },
        schoolName = school.ifBlank { "সরকারি প্রাথমিক বিদ্যালয়" },
        avatarId = avatarId
      )
      repository.saveProfile(updated)
    }
  }

  fun clearAllHistory() {
    viewModelScope.launch {
      repository.clearHistory()
    }
  }
}

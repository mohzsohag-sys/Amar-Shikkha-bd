package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BengaliUtils
import com.example.model.SubjectType
import com.example.ui.ShikkhaViewModel
import com.example.ui.components.GradeBadge
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
  viewModel: ShikkhaViewModel,
  onStartExam: () -> Unit,
  modifier: Modifier = Modifier
) {
  val attempts by viewModel.allQuizAttempts.collectAsStateWithLifecycle()
  var selectedSubjectFilter by remember { mutableStateOf<String?>("সব") }
  var showClearDialog by remember { mutableStateOf(false) }

  val subjectFilterOptions = listOf("সব", "বাংলা", "ইংরেজি", "গণিত", "বিজ্ঞান")

  val filteredAttempts = if (selectedSubjectFilter == null || selectedSubjectFilter == "সব") {
    attempts
  } else {
    attempts.filter { it.subjectName == selectedSubjectFilter }
  }

  val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    // Header & Clear Action
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp, bottom = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "পরীক্ষার ফলাফল ইতিহাস",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "মোট সম্পন্ন পরীক্ষা: ${BengaliUtils.toBengaliNumber(attempts.size)}টি",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (attempts.isNotEmpty()) {
        IconButton(
          onClick = { showClearDialog = true },
          modifier = Modifier.testTag("clear_history_button")
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "ইতিহাস মুছুন",
            tint = ErrorRed
          )
        }
      }
    }

    // Filter Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      subjectFilterOptions.forEach { filterName ->
        val isSelected = selectedSubjectFilter == filterName
        FilterChip(
          selected = isSelected,
          onClick = { selectedSubjectFilter = filterName },
          label = { Text(filterName) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.18f),
            selectedLabelColor = EmeraldPrimary
          )
        )
      }
    }

    if (filteredAttempts.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(bottom = 60.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(24.dp)
        ) {
          Box(
            modifier = Modifier
              .size(72.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.History,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(36.dp)
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = "এখনো কোনো পরীক্ষার রেকর্ড নেই",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "যেকোনো বিষয়ের অধ্যায় থেকে কুইজে অংশ নিলে ফলাফল ও অগ্রগতি এখানে সংরক্ষিত থাকবে।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 20.sp
          )

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = onStartExam,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("কুইজ শুরু করুন")
          }
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp)
      ) {
        items(filteredAttempts) { attempt ->
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(EmeraldPrimary.copy(alpha = 0.12f))
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(
                      text = "${attempt.classGradeName} • ${attempt.subjectName}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldPrimary
                    )
                  }
                }

                GradeBadge(
                  grade = "গ্রেড: ${attempt.gradeLetter}",
                  backgroundColor = if (attempt.percentage >= 80) SuccessGreen else if (attempt.percentage >= 50) AmberSecondary else ErrorRed
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = attempt.chapterTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = "প্রাপ্ত নম্বর: ${BengaliUtils.toBengaliNumber(attempt.correctAnswers)} / ${BengaliUtils.toBengaliNumber(attempt.totalQuestions)} (${BengaliUtils.toBengaliPercent(attempt.percentage)})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (attempt.percentage >= 60) SuccessGreen else ErrorRed
                  )

                  Text(
                    text = dateFormat.format(Date(attempt.timestamp)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Box(
                  modifier = Modifier
                    .clip(CircleShape)
                    .background(
                      if (attempt.percentage >= 60) SuccessGreen.copy(alpha = 0.15f)
                      else ErrorRed.copy(alpha = 0.15f)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                  Text(
                    text = BengaliUtils.toBengaliPercent(attempt.percentage),
                    fontWeight = FontWeight.Bold,
                    color = if (attempt.percentage >= 60) SuccessGreen else ErrorRed,
                    fontSize = 13.sp
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Clear Confirmation Dialog
  if (showClearDialog) {
    AlertDialog(
      onDismissRequest = { showClearDialog = false },
      title = { Text("ইতিহাস মুছে ফেলতে চান?") },
      text = { Text("আপনার সব পূর্ববর্তী পরীক্ষার ফলাফল মুছে যাবে। আপনি কি নিশ্চিত?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearAllHistory()
            showClearDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
        ) {
          Text("মুছে ফেলুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearDialog = false }) {
          Text("বাতিল")
        }
      }
    )
  }
}

package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ShikkhaDao {

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQuizAttempt(attempt: QuizAttemptEntity): Long

  @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC")
  fun getAllQuizAttempts(): Flow<List<QuizAttemptEntity>>

  @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC LIMIT :limit")
  fun getRecentQuizAttempts(limit: Int): Flow<List<QuizAttemptEntity>>

  @Query("SELECT * FROM quiz_attempts WHERE chapterId = :chapterId ORDER BY timestamp DESC")
  fun getAttemptsForChapter(chapterId: String): Flow<List<QuizAttemptEntity>>

  @Query("SELECT * FROM student_profile WHERE id = 1 LIMIT 1")
  fun getStudentProfile(): Flow<StudentProfileEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateProfile(profile: StudentProfileEntity)

  @Query("UPDATE student_profile SET totalPoints = totalPoints + :points, starsCount = starsCount + :stars WHERE id = 1")
  suspend fun addPointsAndStars(points: Int, stars: Int)

  @Query("DELETE FROM quiz_attempts")
  suspend fun clearAllHistory()
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BengaliUtils
import com.example.model.Question
import com.example.ui.ShikkhaViewModel
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen

@Composable
fun QuizScreen(
  viewModel: ShikkhaViewModel,
  onFinishQuiz: () -> Unit,
  modifier: Modifier = Modifier
) {
  val quizState by viewModel.quizState.collectAsStateWithLifecycle()
  val chapter = quizState.chapter

  if (chapter == null || chapter.questions.isEmpty()) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("কুইজের কোনো প্রশ্ন পাওয়া যায়নি")
    }
    return
  }

  val totalQuestions = chapter.questions.size
  val currentIndex = quizState.currentQuestionIndex
  val currentQuestion = chapter.questions.getOrNull(currentIndex) ?: return
  val progress = (currentIndex + 1).toFloat() / totalQuestions
  val isLastQuestion = currentIndex == totalQuestions - 1

  val optionLabels = listOf("ক", "খ", "গ", "ঘ")

  Column(modifier = modifier.fillMaxSize()) {
    // 1. Top Question Progress Bar
    Surface(
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${chapter.classGrade.banglaName} • ${chapter.subjectType.banglaName}",
            style = MaterialTheme.typography.bodySmall,
            color = chapter.subjectType.primaryColor,
            fontWeight = FontWeight.Bold
          )

          Text(
            text = "প্রশ্ন: ${BengaliUtils.toBengaliNumber(currentIndex + 1)} / ${BengaliUtils.toBengaliNumber(totalQuestions)}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = chapter.subjectType.primaryColor,
          trackColor = chapter.subjectType.lightColor
        )
      }
    }

    // 2. Question & Options Scrollable Area
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
    ) {
      // Question Card
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("quiz_question_card")
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(chapter.subjectType.primaryColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = BengaliUtils.toBengaliNumber(currentIndex + 1),
                  fontWeight = FontWeight.Bold,
                  color = chapter.subjectType.primaryColor,
                  fontSize = 13.sp
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "সঠিক উত্তরটি নির্বাচন করো:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = currentQuestion.questionText,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              lineHeight = 28.sp
            )
          }
        }
      }

      // 4 Options
      items(currentQuestion.options.size) { optionIndex ->
        val optionText = currentQuestion.options[optionIndex]
        val label = optionLabels.getOrElse(optionIndex) { "${optionIndex + 1}" }
        val isSelected = quizState.selectedOptionIndex == optionIndex
        val isConfirmed = quizState.isAnswerConfirmed
        val isCorrectOption = optionIndex == currentQuestion.correctIndex

        // Visual Colors based on confirmation state
        val (cardBg, borderColor, textColor, badgeColor) = when {
          isConfirmed && isCorrectOption -> {
            // Correct option always highlighted green
            Quad(
              Color(0xFFDCFCE7),
              SuccessGreen,
              Color(0xFF14532D),
              SuccessGreen
            )
          }
          isConfirmed && isSelected && !isCorrectOption -> {
            // Wrong selection highlighted red
            Quad(
              Color(0xFFFEE2E2),
              ErrorRed,
              Color(0xFF7F1D1D),
              ErrorRed
            )
          }
          isSelected -> {
            // Selected before confirmation
            Quad(
              chapter.subjectType.lightColor,
              chapter.subjectType.primaryColor,
              MaterialTheme.colorScheme.onSurface,
              chapter.subjectType.primaryColor
            )
          }
          else -> {
            // Unselected default
            Quad(
              MaterialTheme.colorScheme.surface,
              MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
              MaterialTheme.colorScheme.onSurface,
              MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            )
          }
        }

        OutlinedCard(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.outlinedCardColors(containerColor = cardBg),
          border = BorderStroke(if (isSelected || (isConfirmed && isCorrectOption)) 2.dp else 1.dp, borderColor),
          modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isConfirmed) {
              viewModel.selectQuizOption(optionIndex)
            }
            .testTag("quiz_option_$optionIndex")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(badgeColor.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = badgeColor
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
              text = optionText,
              style = MaterialTheme.typography.bodyLarge,
              fontWeight = if (isSelected || (isConfirmed && isCorrectOption)) FontWeight.Bold else FontWeight.Normal,
              color = textColor,
              modifier = Modifier.weight(1f)
            )

            if (isConfirmed) {
              if (isCorrectOption) {
                Icon(
                  Icons.Default.Check,
                  contentDescription = "সঠিক উত্তর",
                  tint = SuccessGreen,
                  modifier = Modifier.size(24.dp)
                )
              } else if (isSelected) {
                Icon(
                  Icons.Default.Close,
                  contentDescription = "ভুল উত্তর",
                  tint = ErrorRed,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
          }
        }
      }

      // 3. Detailed Explanation Box after answer confirmation
      item {
        AnimatedVisibility(
          visible = quizState.isAnswerConfirmed,
          enter = fadeIn() + slideInVertically()
        ) {
          val isCorrect = quizState.selectedOptionIndex == currentQuestion.correctIndex
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isCorrect) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
            ),
            border = BorderStroke(
              1.dp,
              if (isCorrect) SuccessGreen.copy(alpha = 0.5f) else ErrorRed.copy(alpha = 0.5f)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("explanation_card")
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Info,
                  contentDescription = null,
                  tint = if (isCorrect) SuccessGreen else ErrorRed,
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (isCorrect) "চমৎকার! সঠিক উত্তর!" else "সঠিক উত্তরটি দেখে নাও:",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (isCorrect) SuccessGreen else ErrorRed
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "ব্যাখ্যা ও সমাধান: ${currentQuestion.explanation}",
                style = MaterialTheme.typography.bodyMedium,
                lineHeight = 22.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // 4. Bottom Action Button
    Surface(
      shadowElevation = 8.dp,
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Box(modifier = Modifier.padding(16.dp)) {
        if (!quizState.isAnswerConfirmed) {
          Button(
            onClick = { viewModel.confirmAnswer() },
            enabled = quizState.selectedOptionIndex != null,
            colors = ButtonDefaults.buttonColors(containerColor = chapter.subjectType.primaryColor),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("confirm_answer_button")
          ) {
            Text(
              text = "উত্তর নিশ্চিত করুন",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }
        } else {
          Button(
            onClick = {
              if (isLastQuestion) {
                viewModel.nextQuestion()
                onFinishQuiz()
              } else {
                viewModel.nextQuestion()
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("next_question_button")
          ) {
            Text(
              text = if (isLastQuestion) "পরীক্ষার ফলাফল দেখুন" else "পরবর্তী প্রশ্ন",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              if (isLastQuestion) Icons.Default.DoneAll else Icons.Default.ArrowForward,
              contentDescription = null,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}

// Data holder for 4-tuple color mapping
private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

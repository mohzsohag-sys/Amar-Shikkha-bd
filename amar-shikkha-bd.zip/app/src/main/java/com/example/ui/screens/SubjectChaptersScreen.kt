package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CurriculumData
import com.example.model.BengaliUtils
import com.example.model.Chapter
import com.example.ui.ShikkhaViewModel

@Composable
fun SubjectChaptersScreen(
  viewModel: ShikkhaViewModel,
  onOpenLesson: (Chapter) -> Unit,
  onStartQuiz: (Chapter) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedGrade by viewModel.selectedGrade.collectAsStateWithLifecycle()
  val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
  val attempts by viewModel.allQuizAttempts.collectAsStateWithLifecycle()

  val chapters = CurriculumData.getChapters(selectedGrade, selectedSubject)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
  ) {
    // Subject Header Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("subject_header_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = selectedSubject.lightColor)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(selectedSubject.primaryColor)
                .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(
                text = selectedGrade.banglaName,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }

            Text(
              text = "মোট ${BengaliUtils.toBengaliNumber(chapters.size)}টি অধ্যায়",
              style = MaterialTheme.typography.bodySmall,
              color = selectedSubject.primaryColor,
              fontWeight = FontWeight.SemiBold
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "${selectedSubject.banglaName} - অধ্যায় ও পাঠসমূহ",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Text(
            text = "অধ্যায়গুলো পড়ে সম্পূর্ণ প্রস্তুতি নাও এবং কুইজে অংশ নিয়ে নিজের মেধা যাচাই করো।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // List of Chapters
    items(chapters) { chapter ->
      val chapterAttempts = attempts.filter { it.chapterId == chapter.id }
      val isCompleted = chapterAttempts.isNotEmpty()
      val highestScore = chapterAttempts.maxOfOrNull { it.percentage }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("chapter_card_${chapter.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(selectedSubject.primaryColor.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = chapter.chapterNumberBengali,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = selectedSubject.primaryColor
              )
            }

            if (isCompleted && highestScore != null) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFFDCFCE7))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = "সম্পন্ন",
                  tint = Color(0xFF16A34A),
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "সেরা স্কোর: ${BengaliUtils.toBengaliPercent(highestScore)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF16A34A)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = chapter.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )

          Text(
            text = chapter.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.AccessTime,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${BengaliUtils.toBengaliNumber(chapter.readingMinutes)} মিনিট পাঠ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.Quiz,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${BengaliUtils.toBengaliNumber(chapter.questions.size)}টি বহুনির্বাচনী প্রশ্ন",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = { onOpenLesson(chapter) },
              modifier = Modifier
                .weight(1f)
                .testTag("read_lesson_button_${chapter.id}"),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("পাঠ পড়ুন")
            }

            Button(
              onClick = { onStartQuiz(chapter) },
              modifier = Modifier
                .weight(1f)
                .testTag("start_quiz_button_${chapter.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = selectedSubject.primaryColor),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("কুইজ দিন")
            }
          }
        }
      }
    }
  }
}

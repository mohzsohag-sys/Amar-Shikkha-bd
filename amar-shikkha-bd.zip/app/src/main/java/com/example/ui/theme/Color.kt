package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald & Forest Green Palette
val EmeraldPrimary = Color(0xFF0D9488)
val EmeraldDark = Color(0xFF0F766E)
val EmeraldLight = Color(0xFF2DD4BF)
val EmeraldContainer = Color(0xFFCCFBF1)
val OnEmeraldContainer = Color(0xFF115E59)

// Amber / Gold Palette
val AmberSecondary = Color(0xFFF59E0B)
val AmberDark = Color(0xFFD97706)
val AmberLight = Color(0xFFFDE68A)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF78350F)

// Royal Sky & Sapphire Palette
val SkyTertiary = Color(0xFF0284C7)
val SkyDark = Color(0xFF0369A1)
val SkyLight = Color(0xFFBAE6FD)
val SkyContainer = Color(0xFFE0F2FE)
val OnSkyContainer = Color(0xFF075985)

// Subject Accent Colors
val BanglaGreen = Color(0xFF16A34A)
val BanglaGreenLight = Color(0xFFDCFCE7)
val EnglishBlue = Color(0xFF2563EB)
val EnglishBlueLight = Color(0xFFDBEAFE)
val MathAmber = Color(0xFFEA580C)
val MathAmberLight = Color(0xFFFFEDD5)
val SciencePurple = Color(0xFF9333EA)
val SciencePurpleLight = Color(0xFFF3E8FF)

// Feedback & Status
val SuccessGreen = Color(0xFF22C55E)
val ErrorRed = Color(0xFFEF4444)
val WarningYellow = Color(0xFFEAB308)
val InfoBlue = Color(0xFF3B82F6)

// Neutral Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme equivalents
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)

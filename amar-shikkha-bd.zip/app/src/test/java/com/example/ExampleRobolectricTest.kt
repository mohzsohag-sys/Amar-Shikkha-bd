package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CurriculumData
import com.example.model.BengaliUtils
import com.example.model.ClassGrade
import com.example.model.SubjectType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameString() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Amar Shikkha bd", appName)
  }

  @Test
  fun testBengaliDigitConversion() {
    assertEquals("১", BengaliUtils.toBengaliNumber(1))
    assertEquals("১০", BengaliUtils.toBengaliNumber(10))
    assertEquals("৮৫%", BengaliUtils.toBengaliPercent(85))
  }

  @Test
  fun testCurriculumCoversAllClassesAndSubjects() {
    ClassGrade.values().forEach { grade ->
      SubjectType.values().forEach { subject ->
        val chapters = CurriculumData.getChapters(grade, subject)
        assertTrue("Grade ${grade.banglaName} Subject ${subject.banglaName} must have chapters", chapters.isNotEmpty())
        chapters.forEach { chapter ->
          assertTrue("Chapter must have sections", chapter.sections.isNotEmpty())
          assertTrue("Chapter must have MCQ questions", chapter.questions.isNotEmpty())
          chapter.questions.forEach { q ->
            assertEquals("MCQ must have 4 options", 4, q.options.size)
            assertTrue("Correct index must be 0..3", q.correctIndex in 0..3)
            assertNotNull("Explanation must not be empty", q.explanation)
          }
        }
      }
    }
  }

  @Test
  fun testGradeCalculation() {
    val (gradeLetter, _) = BengaliUtils.getGradeDetails(95)
    assertEquals("A+", gradeLetter)

    val (gradeB, _) = BengaliUtils.getGradeDetails(65)
    assertEquals("B", gradeB)
  }
}

package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BanglaGreen
import com.example.ui.theme.BanglaGreenLight
import com.example.ui.theme.EnglishBlue
import com.example.ui.theme.EnglishBlueLight
import com.example.ui.theme.MathAmber
import com.example.ui.theme.MathAmberLight
import com.example.ui.theme.SciencePurple
import com.example.ui.theme.SciencePurpleLight

enum class ClassGrade(
  val levelNumber: Int,
  val banglaName: String,
  val shortBadge: String,
  val description: String
) {
  CLASS_1(1, "১ম শ্রেণি", "কুঁড়ি", "সহজ ও মজার বর্ণমালা, শব্দ ও গণনা"),
  CLASS_2(2, "২য় শ্রেণি", "কলি", "যুক্তবর্ণ, নামতা, পশু-পাখি ও চারপাশ"),
  CLASS_3(3, "৩য় শ্রেণি", "মুকুল", "গল্প, ব্যাকরণ, স্থানীয় মান ও বিজ্ঞান"),
  CLASS_4(4, "৪র্থ শ্রেণি", "পাপড়ি", "ভগ্নাংশ, পুষ্টি, দেশপ্রেম ও ব্যাকরণ"),
  CLASS_5(5, "৫ম শ্রেণি", "প্রস্ফুটিত", "ঐকিক নিয়ম, মহাবিশ্ব, সমাপনী প্রস্তুতি")
}

enum class SubjectType(
  val banglaName: String,
  val englishName: String,
  val description: String,
  val primaryColor: Color,
  val lightColor: Color
) {
  BANGLA(
    banglaName = "বাংলা",
    englishName = "Bangla",
    description = "গল্প, ছড়া, ব্যাকরণ ও পাঠ",
    primaryColor = BanglaGreen,
    lightColor = BanglaGreenLight
  ),
  ENGLISH(
    banglaName = "ইংরেজি",
    englishName = "English",
    description = "Grammar, Stories & Rhymes",
    primaryColor = EnglishBlue,
    lightColor = EnglishBlueLight
  ),
  MATH(
    banglaName = "গণিত",
    englishName = "Mathematics",
    description = "সংখ্যা, যোগ, বিয়োগ, গুণ, ভাগ ও জ্যামিতি",
    primaryColor = MathAmber,
    lightColor = MathAmberLight
  ),
  SCIENCE(
    banglaName = "বিজ্ঞান",
    englishName = "Science",
    description = "প্রকৃতি, স্বাস্থ্য, পরিবেশ ও প্রযুক্তি",
    primaryColor = SciencePurple,
    lightColor = SciencePurpleLight
  )
}

data class LessonSection(
  val title: String,
  val bodyText: String,
  val bulletPoints: List<String> = emptyList(),
  val specialBoxTitle: String? = null,
  val specialBoxContent: String? = null
)

data class Question(
  val id: String,
  val questionText: String,
  val options: List<String>,
  val correctIndex: Int,
  val explanation: String,
  val hint: String? = null
)

data class Chapter(
  val id: String,
  val classGrade: ClassGrade,
  val subjectType: SubjectType,
  val chapterNumberBengali: String,
  val title: String,
  val subtitle: String,
  val readingMinutes: Int,
  val sections: List<LessonSection>,
  val questions: List<Question>
)

data class QuizSummary(
  val chapterId: String,
  val chapterTitle: String,
  val subjectType: SubjectType,
  val classGrade: ClassGrade,
  val totalQuestions: Int,
  val correctCount: Int,
  val wrongCount: Int,
  val percentage: Int,
  val gradeLetter: String,
  val gradeTitle: String,
  val timestamp: Long = System.currentTimeMillis(),
  val userSelectedAnswers: Map<Int, Int> // questionIndex -> selectedOptionIndex
)

object BengaliUtils {
  private val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

  fun toBengaliNumber(number: Int): String {
    val str = number.toString()
    val builder = StringBuilder()
    for (ch in str) {
      if (ch in '0'..'9') {
        builder.append(bengaliDigits[ch - '0'])
      } else {
        builder.append(ch)
      }
    }
    return builder.toString()
  }

  fun toBengaliPercent(number: Int): String {
    return "${toBengaliNumber(number)}%"
  }

  fun getGradeDetails(percentage: Int): Pair<String, String> {
    return when {
      percentage >= 90 -> Pair("A+", "অসাধারণ! সম্পূর্ণ নিখুঁত প্রস্তুতি!")
      percentage >= 80 -> Pair("A", "চমৎকার! তুমি খুব ভালো করেছো!")
      percentage >= 70 -> Pair("A-", "বেশ ভালো! আরও একটু চেষ্টা করো!")
      percentage >= 60 -> Pair("B", "ভালো! পাঠটি আরেকবার পড়ে নাও!")
      percentage >= 50 -> Pair("C", "উত্তীর্ণ! পুনরায় কুইজটি চেষ্টা করো!")
      else -> Pair("F", "পুনরায় চেষ্টা প্রয়োজন! পাঠটি মনোযোগ দিয়ে পড়ো!")
    }
  }
}

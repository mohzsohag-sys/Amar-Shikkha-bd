package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CurriculumData
import com.example.model.BengaliUtils
import com.example.model.ClassGrade
import com.example.model.SubjectType
import com.example.ui.ShikkhaViewModel
import com.example.ui.components.StatCard
import com.example.ui.theme.AmberDark
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SkyTertiary

@Composable
fun HomeScreen(
  viewModel: ShikkhaViewModel,
  onNavigateToSubject: (SubjectType) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedGrade by viewModel.selectedGrade.collectAsStateWithLifecycle()
  val profile by viewModel.studentProfile.collectAsStateWithLifecycle()
  val attempts by viewModel.allQuizAttempts.collectAsStateWithLifecycle()

  val totalTests = attempts.size
  val averageScore = if (totalTests > 0) {
    attempts.map { it.percentage }.average().toInt()
  } else 0

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
  ) {
    // 1. Welcome & Motivation Hero Banner
    item {
      ElevatedCard(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("home_hero_banner"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.Transparent)
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.horizontalGradient(
                colors = listOf(EmeraldDark, EmeraldPrimary)
              )
            )
            .padding(20.dp)
        ) {
          Column {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "আমার শিক্ষা বিডি",
                  style = MaterialTheme.typography.headlineMedium,
                  color = Color.White,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "১ম থেকে ৫ম শ্রেণির পূর্ণাঙ্গ শিক্ষামূলক অ্যাপ",
                  style = MaterialTheme.typography.bodyMedium,
                  color = Color.White.copy(alpha = 0.9f)
                )
              }
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.AutoStories,
                  contentDescription = "শিক্ষা",
                  tint = Color.White,
                  modifier = Modifier.size(28.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color.White.copy(alpha = 0.15f)
            ) {
              Text(
                text = "💡 আজকের বাণী: প্রতিদিন একটু একটু শিখে বড় মানুষ হও!",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    }

    // 2. Class Level Selector (১ম, ২য়, ৩য়, ৪র্থ, ৫ম শ্রেণি)
    item {
      Column {
        Text(
          text = "শ্রেণি নির্বাচন করুন",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "তোমার শ্রেণির পাঠ্যবই এবং কুইজ দেখার জন্য ট্যাপ করো",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          ClassGrade.values().forEach { grade ->
            val isSelected = grade == selectedGrade
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.selectGrade(grade) },
              label = {
                Text(
                  text = grade.banglaName,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              },
              leadingIcon = {
                Text(
                  text = grade.shortBadge,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = EmeraldPrimary.copy(alpha = 0.18f),
                selectedLabelColor = EmeraldPrimary
              ),
              modifier = Modifier.testTag("class_chip_${grade.levelNumber}")
            )
          }
        }
      }
    }

    // 3. Quick Stats Cards (পরীক্ষা, পয়েন্ট, স্টার)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        StatCard(
          title = "মোট পরীক্ষা",
          value = BengaliUtils.toBengaliNumber(totalTests),
          icon = Icons.Default.EmojiEvents,
          iconTint = AmberSecondary,
          modifier = Modifier.weight(1f)
        )
        StatCard(
          title = "গড় নম্বর",
          value = BengaliUtils.toBengaliPercent(averageScore),
          icon = Icons.Default.Star,
          iconTint = EmeraldPrimary,
          modifier = Modifier.weight(1f)
        )
        StatCard(
          title = "অর্জিত পয়েন্ট",
          value = BengaliUtils.toBengaliNumber(profile?.totalPoints ?: 0),
          icon = Icons.Default.Psychology,
          iconTint = SkyTertiary,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 4. Subjects Section Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "চারটি মূল বিষয় (${selectedGrade.banglaName})",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = selectedGrade.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // 5. Four Subject Cards: Bangla, English, Mathematics, Science
    SubjectType.values().forEach { subject ->
      item {
        SubjectCardItem(
          subject = subject,
          grade = selectedGrade,
          onClick = {
            viewModel.selectSubject(subject)
            onNavigateToSubject(subject)
          }
        )
      }
    }
  }
}

@Composable
fun SubjectCardItem(
  subject: SubjectType,
  grade: ClassGrade,
  onClick: () -> Unit
) {
  val chapters = CurriculumData.getChapters(grade, subject)
  val chapterCount = chapters.size

  val icon: ImageVector = when (subject) {
    SubjectType.BANGLA -> Icons.Default.MenuBook
    SubjectType.ENGLISH -> Icons.Default.Translate
    SubjectType.MATH -> Icons.Default.Calculate
    SubjectType.SCIENCE -> Icons.Default.Science
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("subject_card_${subject.name}"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(subject.lightColor),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = subject.banglaName,
          tint = subject.primaryColor,
          modifier = Modifier.size(28.dp)
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = subject.banglaName,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "(${subject.englishName})",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Text(
          text = subject.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(subject.lightColor)
              .padding(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${BengaliUtils.toBengaliNumber(chapterCount)}টি অধ্যায় ও পাঠ",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = subject.primaryColor
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "• বহুনির্বাচনী কুইজ সহ",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(subject.primaryColor.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "প্রবেশ করুন",
          tint = subject.primaryColor,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}
